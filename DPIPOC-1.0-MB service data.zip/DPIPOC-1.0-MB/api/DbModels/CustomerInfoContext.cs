using api.Models;
using Microsoft.EntityFrameworkCore;

namespace api.DbModels

{
    public class CustomerInfoContext : DbContext
    {
        public CustomerInfoContext(DbContextOptions<CustomerInfoContext> options) : base(options)
        {
        }

        public DbSet<CustomerInfo> CustomerInfo { get; set; }
    }
}