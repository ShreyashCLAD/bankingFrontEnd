using System;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace api.Models
{
    public class CustomerInfo
    {
        
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]

         [Key]
        public int CId { get; set; }
        [Required]

        public string Firstname { get; set; }
        [Required]

        public string Lastname { get; set; }
        [Required]

        public DateTime Date { get; set; }
        [Required]
        public string Email { get; set; }
        [Required]
        public string MobileNo { get; set; }
        
 
    }
}