using System;

namespace api.Models
{
    public class CustomerAddress
    {
        /*public int CId { get; set; }*/

        public string Address { get; set; }

        public string City { get; set; }

        public string State { get; set; }

        public int Pin { get; set; }

        public string Country { get; set; }

    }
}