using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using api.Models;
using Microsoft.AspNetCore.Cors;
using api.DbModels;

namespace api.Controllers{

    [ApiController]
    [Route("[controller]")]
    public class CustomerInfoController : ControllerBase
    {
        private readonly CustomerInfoContext _context;
         private readonly ILogger<CustomerInfoController> _logger;
        public CustomerInfoController(ILogger<CustomerInfoController> logger, CustomerInfoContext context)
        {
            _context = context;
            _logger = logger;
        }
        [HttpGet]
        [Route("customer")]
        public IEnumerable<CustomerInfo> Get()
        {
            var result = new List<CustomerInfo>();
            result = _context.CustomerInfo.ToList();
            return result;
        }
    }  
}