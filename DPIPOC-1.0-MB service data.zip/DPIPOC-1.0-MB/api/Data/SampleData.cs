using System.Collections.Generic;
using api.DbModels;
using api.Models;
using System;
namespace api.Data
{
    public static class SampleData
    {
        public static void AddCustomerData(CustomerInfoContext context)
        {
            var customerInfo = new List<CustomerInfo>();
            customerInfo.Add(new CustomerInfo
            {
                CId = 47,
                Firstname ="John",
                Lastname = "Carter",
                Date = DateTime.Now,
                Email = "user+1@diaspark.com",
                MobileNo = "7411536056"
            });
            // customers.Add(new Models.Customer
            // {
            //     Id = Guid.NewGuid(),
            //     No = "0090",
            //     Name = "INTERNATIONAL BANK CORP",
            //     City ="NEW YORK",
            //     State = "NY",
            //     Zip = "100059989"
            // });
            // customers.Add(new Models.Customer
            // {
            //     Id = Guid.NewGuid(),
            //     No = "0150",
            //     Name = "IMPERIAL BANKCORP",
            //     City ="NEW YORK",
            //     State = "NY",
            //     Zip = "100190000"
            // });
            // customers.Add(new Models.Customer
            // {
            //     Id = Guid.NewGuid(),
            //     No = "0170",
            //     Name = "UNITED ATLANTIC SHARES",
            //     City ="CHARLOTTE",
            //     State = "NC",
            //     Zip = "282552550"
            // });
            // customers.Add(new Models.Customer
            // {
            //     Id = Guid.NewGuid(),
            //     No = "0190",
            //     Name = "SOUTHWEST STATE OIL REFINING",
            //     City ="SHERMAN OAKS",
            //     State = "CA",
            //     Zip = "914231423"
            // });
            // customers.Add(new Models.Customer
            // {
            //     Id = Guid.NewGuid(),
            //     No = "0210",
            //     Name = "WEST LIFE INSURANCE",
            //     City ="BALTIMORE",
            //     State = "MD",
            //     Zip = "212031203"
            // });
             context.CustomerInfo.AddRange(customerInfo);
            context.SaveChanges();
        }
    }
}