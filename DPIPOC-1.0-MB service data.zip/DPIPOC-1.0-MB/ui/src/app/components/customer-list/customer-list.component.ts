import { Component, OnInit, ViewChild } from "@angular/core";
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import {SelectionModel} from '@angular/cdk/collections';
import { CustomerService } from "../../services/customer.service";
import { Customer } from "../../services/customer.model";
import { MatDialog, MatDialogConfig } from "@angular/material";
import { CustomerDetailsComponent } from '../customer-details/customer-details.component';

export interface PeriodicElement {
  firstName: string;
  position: number;
  DOB: string
  lastName: string;
  Address:string
  country:string
  city:string
  Mobileno:number
  email:string
}

let ELEMENT_DATA: PeriodicElement[] = [
  {position: 1, firstName: 'Hydrogen', DOB: "11-3-2019", lastName: 'H',Address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:895930564},
  {position: 2, firstName: 'Helium', DOB: "11-3-2019", lastName: 'He',Address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:896487456},
  {position: 1, firstName: 'Hydrogen', DOB: "11-3-2019", lastName: 'H',Address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:895930564},
  {position: 2, firstName: 'Helium', DOB: "11-3-2019", lastName: 'He',Address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:896487456},
  {position: 1, firstName: 'Hydrogen', DOB: "11-3-2019", lastName: 'H',Address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:895930564},
  {position: 2, firstName: 'Helium', DOB: "11-3-2019", lastName: 'He',Address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:896487456},
  {position: 1, firstName: 'Hydrogen', DOB: "11-3-2019", lastName: 'H',Address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:895930564},
  {position: 2, firstName: 'Helium', DOB: "11-3-2019", lastName: 'He',Address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:896487456},
  {position: 1, firstName: 'Hydrogen', DOB: "11-3-2019", lastName: 'H',Address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:895930564},
  {position: 2, firstName: 'Helium', DOB: "11-3-2019", lastName: 'He',Address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:896487456},
  {position: 1, firstName: 'Hydrogen', DOB: "11-3-2019", lastName: 'H',Address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:895930564},
  {position: 2, firstName: 'Helium', DOB: "11-3-2019", lastName: 'He',Address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:896487456},
  {position: 1, firstName: 'Hydrogen', DOB: "11-3-2019", lastName: 'H',Address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:895930564},
  {position: 2, firstName: 'Helium', DOB: "11-3-2019", lastName: 'He',Address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:896487456},
  {position: 1, firstName: 'Hydrogen', DOB: "11-3-2019", lastName: 'H',Address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:895930564},
  {position: 2, firstName: 'Helium', DOB: "11-3-2019", lastName: 'He',Address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:896487456},
  {position: 1, firstName: 'Hydrogen', DOB: "11-3-2019", lastName: 'H',Address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:895930564},
  {position: 2, firstName: 'Helium', DOB: "11-3-2019", lastName: 'He',Address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:896487456},
  {position: 1, firstName: 'Hydrogen', DOB: "11-3-2019", lastName: 'H',Address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:895930564},
  {position: 2, firstName: 'Helium', DOB: "11-3-2019", lastName: 'He',Address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:896487456},
  {position: 1, firstName: 'Hydrogen', DOB: "11-3-2019", lastName: 'H',Address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:895930564},
  {position: 2, firstName: 'Helium', DOB: "11-3-2019", lastName: 'He',Address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',Mobileno:896487456},
];

/** Constants used to fill up our data base. */


@Component({
  selector: "app-customer-list",
  templateUrl: "./customer-list.component.html",
  styleUrls: ["./customer-list.component.css"]
})
export class CustomerListComponent implements OnInit {
  displayedColumns: string[] = [ 'Name','email','Address','DOB','Mobileno','actions'];
  dataFromService: Customer[];

  @ViewChild(MatSort, {static: true}) sort: MatSort;
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  
  selection = new SelectionModel<PeriodicElement>(true, []);
  searchKey: string;
  dataSource: MatTableDataSource<Customer>;




  constructor(private service:CustomerService,private dialog: MatDialog) { 
   
}

 
  ngOnInit() {
 
    this.getcustomer(); 
}

addNewUser()
{
  console.log("add user");
}

onSearchClear() {
  this.searchKey = "";
  this.applyFilter();
}

applyFilter() {
  this.dataSource.filter = this.searchKey.trim().toLowerCase();
}

onCreate()
{
  this.service.initializeFormGroup();
  const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "60%";
    this.dialog.open(CustomerDetailsComponent,dialogConfig);
}
  update(row) {
    console.log(row);
  }

  delete(row){
    console.log(row);
  }

  getcustomer() {
    
    this.dataFromService  = this.service.getCustomerList();
    console.log(this.dataFromService);
    this.dataSource = new MatTableDataSource(this.dataFromService);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort; 
  }
}
