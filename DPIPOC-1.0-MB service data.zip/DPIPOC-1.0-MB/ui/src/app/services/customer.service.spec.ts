import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerService } from './customer.service';

describe('CustomerDetailsComponent', () => {
  let service:CustomerService;
  beforeEach(async(() => {
    service=new CustomerService();
  }));

  it('should create the app', () => {
    
    const app = service;
    expect(app).toBeTruthy();
  });

});
